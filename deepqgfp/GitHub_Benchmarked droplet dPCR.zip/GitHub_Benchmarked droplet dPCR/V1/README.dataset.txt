# Drop_v1 > V1
https://universe.roboflow.com/dropletlabeling/drop_v1

Provided by a Roboflow user
License: CC BY 4.0

