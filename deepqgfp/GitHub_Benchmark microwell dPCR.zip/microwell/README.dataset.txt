# Microwell_v1 > 2023-12-13 10:00pm
https://universe.roboflow.com/the-chinese-university-of-hong-kong-hiv7d/microwell_v1

Provided by a Roboflow user
License: CC BY 4.0

